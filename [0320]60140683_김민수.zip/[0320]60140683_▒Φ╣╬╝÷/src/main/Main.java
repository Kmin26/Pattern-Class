package main;

public class Main {
	static private MainFrame mainFrame;
	public static void main(String[] args) {
		mainFrame = new MainFrame();
		mainFrame.setVisible(true);
	}

}

