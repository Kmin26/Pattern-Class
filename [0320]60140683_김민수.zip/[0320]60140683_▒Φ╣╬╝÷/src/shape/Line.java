package shape;

import java.awt.BasicStroke;
import java.awt.Graphics2D;

public class Line extends Shape {

	@Override
	public void draw(Graphics2D graphics) {

		graphics.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, dash, 0));
		graphics.drawLine(x1, y1, x2, y2);

	}

	@Override
	public void draw(boolean mtf, Graphics2D graphics) {
		// TODO Auto-generated method stub

		graphics.setStroke(new BasicStroke());
		graphics.drawLine(x1, y1, x2, y2);
	}

	@Override
	public void tdraw(Graphics2D graphics) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void tdraw(boolean mtf, Graphics2D graphics) {
		// TODO Auto-generated method stub
		
	}
}
