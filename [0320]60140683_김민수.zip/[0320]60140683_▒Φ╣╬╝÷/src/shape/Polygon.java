package shape;

import java.awt.BasicStroke;
import java.awt.Graphics2D;

public class Polygon extends Shape {

	@Override

	public void draw(Graphics2D graphics) {mtf = true;}

	@Override
	public void draw(boolean mtf, Graphics2D graphics) {}

	@Override
	public void tdraw(Graphics2D graphics) {

		if (mtf) { //ó���� 0,0���� ������ �׷����°� �����ϱ� ���ؼ�
			graphics.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, dash, 0));
			graphics.drawLine(x1, y1, x2, y2);
		}

	}

	@Override
	public void tdraw(boolean mtf, Graphics2D graphics) {
		if(this.mtf) {
		graphics.setStroke(new BasicStroke());
		graphics.drawLine(x1, y1, x2, y2);
		System.out.println("yes");
		}
	}

}
