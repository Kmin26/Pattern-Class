package shape;

import java.awt.Graphics2D;

public abstract class Shape {
	protected int x1, x2, y1, y2;
	float dash[] = { 4, 4f };
	float dash1[] = { 1, 0f };
	boolean mtf = false;
	
	public void setOrigin(int x, int y) {
		this.x1 = x;
		this.x2 = x;
		this.y1 = y;
		this.y2 = y;
	}
	public void setPoint(int x, int y) {
		this.x2 = x;
		this.y2 = y;
		
	}
	abstract public void draw(Graphics2D graphics);
	abstract public void draw(boolean mtf, Graphics2D graphics);
	abstract public void tdraw(Graphics2D graphics);
	abstract public void tdraw(boolean mtf,Graphics2D graphics);
}
